<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
               <li><a class="menuitem">Website details</a>
                    <ul class="submenu">
                        <li><a href="social.php">Social Media</a></li>
                        <li><a href="copyright.php">Copyright</a></li>
                        <li><a href="quote.php">Quote</a></li>
                        <li><a href="companyinfo.php">Company info</a></li>
                        <li><a href="headerlogo.php">Header logo</a></li>
                    </ul>
                </li>
                <li><a class="menuitem">FAQ</a>
                    <ul class="submenu">
                        <li><a href="adminfaq.php">Add FAQ</a> </li>
                        <li><a href="adminfaqlist.php">FAQ list</a> </li>
                    </ul>
                </li>
				<li><a class="menuitem">Slider Option</a>
                    <ul class="submenu">
                        <li><a href="slideradd.php">Add Slider</a> </li>
                        <li><a href="sliderlist.php">Slider List</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Category Option</a>
                    <ul class="submenu">
                        <li><a href="catadd.php">Add Category</a> </li>
                        <li><a href="catlist.php">Category List</a> </li>
                    </ul>                
                <li><a class="menuitem">Brand Option</a>
                    <ul class="submenu">
                        <li><a href="brandadd.php">Add Brand</a> </li>
                        <li><a href="brandlist.php">Brand List</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Product Option</a>
                    <ul class="submenu">
                        <li><a href="productadd.php">Add Product</a> </li>
                        <li><a href="productlist.php">Product List</a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>