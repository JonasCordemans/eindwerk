<?php include 'inc/header.php'; ?>

<div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    			<h3>Over ons</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
    </div>
</div>

<div class="container">
	<p>Wat begon als een hobby is indertussen een klein familiebedrijf geworden. We zijn reeds 6 jaar actief in Vlaams-Brabant en omstreken en leveren zo snel mogelijk tegen een zo klein mogelijke prijs. 
	Het gehele proces gebeurd in eigen beheer, van bestellingen ontvangen tot en met het leveren van de produkten. </p>
</div>

<?php include 'inc/footer.php'; ?>
